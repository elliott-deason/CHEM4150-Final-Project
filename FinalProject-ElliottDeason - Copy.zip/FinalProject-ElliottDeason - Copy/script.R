#Elliott Deason
#final Project

library(readr)
library(tidyr)
library(dplyr)
library(tidyverse)
library(ggplot2)
library(ggfortify)
library(emmeans)
library(multcomp)
library(HH)

bees <- read.csv("honeybees.csv")

#2015
new <- bees%>%
  na.omit%>%
  filter(year=="2015")
  
ggplot(new, aes(x=nAllNeonic, y=totalprod, shape=Region, color = Region))+
  geom_point(size=2)+
  xlab("Amount of Neonicotinoids Applied (kg)")+
  ggtitle("Total Honey Produced vs. Neonicotinoids Used in 2015")+
  ylab("Total Honey Produced (lbs)")+
  theme_bw()


model2015 <- lm(totalprod ~ nAllNeonic * Region, data=new)

autoplot(model2015)
anova(model2015)
summary(model2015)

#2005
new1 <- bees%>%
  na.omit%>%
  group_by(Region)%>%
  filter(year=="2005")

ggplot(new1, aes(x=nAllNeonic, y=totalprod, shape = Region, color = Region))+
  geom_point(size=2.7)+
  xlab("Amount of Neonicotinoids Applied (kg)")+
  ylab("Total Honey Produced (lbs)")+
  ggtitle("Total Honey Produced vs. Neonicotinoids Used in 2005")+
  theme_bw()

model2005 <- lm(totalprod ~ nAllNeonic * Region, data=new1)

autoplot(model2005)
anova(model2005)
summary(model2005)

#emmeans 2015
emm_model_2015 <- emmeans(model2015, "Region")
pairs(emm_model_2015)
multcomp::cld(emm_model_2015)

plot(emm_model_2015, comparisons = TRUE)+
  coord_flip()+
  ggtitle("Regional Differences of Total Honey Produced (2015)")+
  xlab("Total Honey Produced (lbs)")+
  theme_bw()

#emmeans 2005
emm_model_2005 <- emmeans(model2005, "Region")
pairs(emm_model_2005)
multcomp::cld(emm_model_2005)

plot(emm_model_2005, comparisons = TRUE)+
  coord_flip()+
  xlab("Total Honey Produced (lbs)")+
  ggtitle("Regional Differences of Total Honey Produced (2005)")+
  theme_bw()

#Analyzing in the West 2015
new2015west <- bees %>%
  na.omit%>%
  filter(Region=="West")%>%
  filter(year=="2015")

ggplot(new2015west, aes(x=nAllNeonic, y=totalprod, shape=Region, color = Region))+
  geom_point(size=2)+
  xlab("Amount of Neonicotinoids Applied (kg)")+
  ggtitle("Total Honey Produced vs. Neonicotinoids Used in 2015 (West Region")+
  ylab("Total Honey Produced (lbs)")+
  theme_bw()

model2015west <- lm(totalprod ~ numcol * nAllNeonic, data=new2015west)

autoplot(model2015west)
anova(model2015west)
summary(model2015west)

#Analyzing in the West 2005
new2005west <- bees %>%
  na.omit%>%
  group_by(Region)%>%
  filter(Region=="West")%>%
  filter(year=="2005")

ggplot(new2005west, aes(x=nAllNeonic, y=totalprod, shape=Region, color = Region))+
  geom_point(size=2)+
  xlab("Amount of Neonicotinoids Applied (kg)")+
  ggtitle("Total Honey Produced vs. Neonicotinoids Used in 2005 (West Region")+
  ylab("Total Honey Produced (lbs)")+
  theme_bw()

model2005west <- lm(totalprod ~ numcol * nAllNeonic, data=new2005west)

autoplot(model2005west)
anova(model2005west)
summary(model2005west)






